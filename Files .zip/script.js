const cells = document.querySelectorAll('[data-cell]');
const winnerModal = document.getElementById('winnerModal');
const winnerText = document.getElementById('winnerText');
const restartButton = document.getElementById('restartButton');

let currentPlayer = 'X';

const WINNING_COMBINATIONS = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6]
];

function startGame() {
  currentPlayer = 'X';
  cells.forEach(cell => {
    cell.textContent = '';
    cell.classList.remove('taken');
    cell.addEventListener('click', handleClick, { once: true });
  });
  winnerModal.style.display = 'none';
}

function handleClick(e) {
  const cell = e.target;
  cell.textContent = currentPlayer;
  cell.classList.add('taken');
  if (checkWin(currentPlayer)) {
    endGame(false);
  } else if (Array.from(cells).every(cell => cell.classList.contains('taken'))) {
    endGame(true);
  } else {
    swapTurns();
  }
}

function endGame(draw) {
  if (draw) {
    winnerText.textContent = "It's a Draw!";
  } else {
    winnerText.textContent = `${currentPlayer} Wins!`;
  }
  winnerModal.style.display = 'flex';
}

function swapTurns() {
  currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
}

function checkWin(player) {
  return WINNING_COMBINATIONS.some(combination => {
    return combination.every(index => {
      return cells[index].textContent === player;
    });
  });
}

restartButton.addEventListener('click', startGame);

startGame();
